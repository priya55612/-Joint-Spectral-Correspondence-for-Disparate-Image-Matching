This is the collection of 46 image pairs used to evaluate symmetry
based detector and descriptor presented in

Image Matching using Local Symmetry Features
by Daniel Cabrini Hauagge and Noah Snavely
CVPR 2012

Each folder contains one pair of images (01.tif and 02.tif) and the file
H1to2 with the homography that takes points in 01.tif to 02.tif.
